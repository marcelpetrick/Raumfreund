enum Zone { green, yellow, red }

class NoiseMonitor {
  double yellow = 60, red = 80;
  Zone zone = Zone.green;
  Duration elapsed = Duration.zero;
  Duration? _since;
  Duration? _last;
  bool _alarmed = false;
  void reset() {
    zone = Zone.green;
    elapsed = Duration.zero;
    _since = null;
    _last = null;
    _alarmed = false;
  }
  bool sample(double db, Duration now) {
    final next = db >= red ? Zone.red : db >= yellow ? Zone.yellow : Zone.green;
    if (next != zone || _since == null || (_last != null && now - _last! > const Duration(seconds: 1))) {
      zone = next;
      _since = now;
      _alarmed = false;
    }
    _last = now;
    elapsed = zone == Zone.green ? Duration.zero : now - _since!;
    if (zone != Zone.green && !_alarmed && elapsed >= const Duration(seconds: 10)) {
      _alarmed = true;
      return true;
    }
    return false;
  }
}
