import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'meter.dart';

void main() => runApp(const Raumfreund());
const bridge = MethodChannel('raumfreund/control');
const readings = EventChannel('raumfreund/levels');

class Raumfreund extends StatelessWidget {
  const Raumfreund({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Raumfreund', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xff397569),
      scaffoldBackgroundColor: const Color(0xfff6f8f1)),
    home: const RoomScreen());
}

class RoomScreen extends StatefulWidget {
  const RoomScreen({super.key});
  @override
  State<RoomScreen> createState() => _RoomState();
}
class _RoomState extends State<RoomScreen> with WidgetsBindingObserver {
  final monitor = NoiseMonitor();
  final clock = Stopwatch();
  StreamSubscription<dynamic>? subscription;
  bool running = false, busy = false, sound = true, loaded = false;
  double db = 0, raw = -90, offset = 90;
  String? error;
  static const colors = [Color(0xff45a879), Color(0xffffc34b), Color(0xffeb7272)];
  @override
  void initState() { super.initState(); WidgetsBinding.instance.addObserver(this); load(); }
  Future<void> load() async {
    try {
      final s = await bridge.invokeMapMethod<String, dynamic>('settings');
      if (!mounted) return;
      setState(() {
        monitor.yellow = (s?['yellow'] as num?)?.toDouble() ?? 60;
        monitor.red = (s?['red'] as num?)?.toDouble() ?? 80;
        offset = (s?['offset'] as num?)?.toDouble() ?? 90;
        sound = s?['sound'] as bool? ?? true;
        loaded = true;
      });
    } catch (_) { if (mounted) setState(() { loaded = true; error = 'Android-Mikrofon ist nicht verfügbar.'; }); }
  }
  Future<void> stop() async {
    running = false;
    await subscription?.cancel(); subscription = null;
    try { await bridge.invokeMethod<void>('stop'); } catch (_) {}
    clock.stop(); monitor.reset();
    if (mounted) setState(() {});
  }
  Future<void> toggle() async {
    if (busy) return;
    setState(() { busy = true; error = null; });
    try {
      if (running) { await stop(); return; }
      monitor.reset(); clock.reset(); clock.start();
      subscription = readings.receiveBroadcastStream().listen((value) {
        if (!running || !mounted) return;
        raw = (value as num).toDouble();
        db = (raw + offset).clamp(0, 130).toDouble();
        final alarm = monitor.sample(db, clock.elapsed);
        setState(() {});
        if (alarm) {
          bridge.invokeMethod<void>('alarm', {'sound': sound}).catchError((Object e) {
            if (mounted) setState(() { error = 'Alarm konnte nicht ausgegeben werden.'; });
          });
        }
      }, onError: (Object e) async {
        await stop();
        if (mounted) setState(() { error = 'Messung unterbrochen. Bitte erneut starten.'; });
      });
      await bridge.invokeMethod<void>('start');
      if (!mounted) return;
      setState(() { running = true; });
    } catch (_) {
      await stop();
      if (mounted) setState(() { error = 'Mikrofonzugriff fehlt oder das Mikrofon ist belegt. Bitte Berechtigung prüfen und erneut starten.'; });
    } finally { if (mounted) setState(() { busy = false; }); }
  }
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.detached) stop();
  }
  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    subscription?.cancel(); bridge.invokeMethod<void>('stop'); super.dispose();
  }
  Future<void> settings() async {
    await stop();
    if (!mounted) return;
    final result = await Navigator.of(context).push<Preferences>(MaterialPageRoute(
      builder: (_) => SettingsScreen(initial: Preferences(monitor.yellow, monitor.red, offset, sound))));
    if (result == null || !mounted) return;
    try {
      await bridge.invokeMethod<void>('saveSettings', {'yellow': result.yellow, 'red': result.red, 'offset': result.offset, 'sound': result.sound});
      setState(() { monitor.yellow = result.yellow; monitor.red = result.red; offset = result.offset; sound = result.sound; });
    } catch (_) { if (mounted) setState(() { error = 'Einstellungen konnten nicht gespeichert werden.'; }); }
  }
  @override
  Widget build(BuildContext context) {
    final zone = running ? monitor.zone.index : 0;
    final color = colors[zone];
    return Scaffold(appBar: AppBar(title: const Text('Raumfreund'), actions: [
      IconButton(tooltip: 'Einstellungen', onPressed: busy || !loaded ? null : settings, icon: const Icon(Icons.tune)),
      IconButton(tooltip: 'Über Raumfreund', onPressed: () async {
        await stop(); if (!context.mounted) return;
        showAboutDialog(context: context, applicationName: 'Raumfreund', applicationVersion: '1.0.0',
          applicationLegalese: 'Erstellt mit OpenAI Codex im Auftrag des Projektinhabers.\nLizenz: GNU GPL v3.0 (GPL-3.0-only).',
          children: const [Text('Eine freundliche Lautstärkeampel für gemeinsame Räume.\n\nBibliotheken: Flutter und Dart (BSD-3-Clause), Kotlin Standard Library (Apache-2.0); Android-Plattform-APIs. Weitere Hinweise über „Lizenzen anzeigen“.\n\nKeine Speicherung oder Übertragung von Audio. Die Messung endet beim Verlassen der App.\n\nGeschätzte dB-Werte: Mit einem Referenzmessgerät kalibrieren. Kein professionelles Schallpegelmessgerät.')]);
      }, icon: const Icon(Icons.info_outline))]),
      body: SafeArea(child: LayoutBuilder(builder: (context, constraints) => SingleChildScrollView(
        child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 560), child: Padding(
          padding: const EdgeInsets.all(24), child: Column(children: [
            const Text('Gemeinsam wird’s gemütlich', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8), const Text('Unser Freund hört mit und zeigt, wie laut es ist.'),
            const SizedBox(height: 28),
            AnimatedContainer(duration: const Duration(milliseconds: 300), padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: color.withValues(alpha: .16), borderRadius: BorderRadius.circular(36)),
              child: SizedBox(width: 230, height: 230, child: CustomPaint(painter: FacePainter(zone, color)))),
            const SizedBox(height: 20),
            Text(!running ? 'Bereit zum Zuhören' : ['Alles im grünen Bereich!', 'Bitte etwas leiser', 'Oh weh, das ist zu laut!'][zone],
              textAlign: TextAlign.center, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            Text(running ? '${db.round()} dB ≈' : '– dB', style: const TextStyle(fontSize: 46, fontWeight: FontWeight.w800)),
            const Text('Geschätzter Schallpegel'), const SizedBox(height: 24),
            Semantics(label: 'Lautstärke-Skala von 0 bis 130 Dezibel', child: SizedBox(height: 38, child: Stack(children: [
              Positioned.fill(child: ClipRRect(borderRadius: BorderRadius.circular(14), child: Row(children: [
                Expanded(flex: monitor.yellow.round(), child: Container(color: colors[0])),
                Expanded(flex: (monitor.red - monitor.yellow).round(), child: Container(color: colors[1])),
                Expanded(flex: (130 - monitor.red).round(), child: Container(color: colors[2]))]))),
              if (running) Align(alignment: Alignment(-1 + 2 * db / 130, 0), child: const Icon(Icons.arrow_drop_down, size: 38, color: Colors.black))]))),
            const SizedBox(height: 8), Text('0 dB  ·  Gelb ${monitor.yellow.round()}  ·  Rot ${monitor.red.round()}  ·  130 dB'),
            const SizedBox(height: 16),
            Text(running && zone != 0 ? (monitor.elapsed.inSeconds >= 10 ? 'Alarm ausgelöst – bitte leiser werden' : 'Alarm in ${10 - monitor.elapsed.inSeconds} Sekunden') : 'Alarm nach 10 Sekunden durchgehend in Gelb oder Rot.', textAlign: TextAlign.center),
            if (error != null) Padding(padding: const EdgeInsets.only(top: 16), child: Text(error!, style: const TextStyle(color: Colors.red))),
            const SizedBox(height: 24), SizedBox(width: double.infinity, child: FilledButton.icon(
              onPressed: busy || !loaded ? null : toggle, icon: Icon(running ? Icons.stop : Icons.mic),
              label: Padding(padding: const EdgeInsets.all(14), child: Text(busy ? 'Bitte warten …' : running ? 'Messung stoppen' : 'Messung starten')))),
            const SizedBox(height: 12), const Text('Das Mikrofon bleibt nur während der Messung aktiv.', textAlign: TextAlign.center),
          ]))))))));
  }
}
class Preferences {
  final double yellow, red, offset; final bool sound;
  const Preferences(this.yellow, this.red, this.offset, this.sound);
}
class SettingsScreen extends StatefulWidget {
  final Preferences initial;
  const SettingsScreen({super.key, required this.initial});
  @override State<SettingsScreen> createState() => _SettingsState();
}
class _SettingsState extends State<SettingsScreen> {
  late double yellow = widget.initial.yellow, red = widget.initial.red, offset = widget.initial.offset;
  late bool sound = widget.initial.sound;
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Einstellungen')),
    body: ListView(padding: const EdgeInsets.all(24), children: [
      const Text('Unsere Lautstärkeampel', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
      const Text('Skala: 0–130 dB. Rot liegt immer über Gelb.'),
      Text('Gelb beginnt bei ${yellow.round()} dB'),
      Slider(value: yellow, min: 0, max: 129, divisions: 129, label: '${yellow.round()} dB', onChanged: (v) => setState(() { yellow = v; if (red <= yellow) red = yellow + 1; })),
      Text('Rot beginnt bei ${red.round()} dB'),
      Slider(value: red, min: 1, max: 130, divisions: 129, label: '${red.round()} dB', onChanged: (v) => setState(() { red = v; if (yellow >= red) yellow = red - 1; })),
      SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Alarmton'), subtitle: const Text('Zusätzlich kurze Vibration, sofern verfügbar.'), value: sound, onChanged: (v) => setState(() { sound = v; })),
      const Divider(), const Text('Kalibrierung', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const Text('Vergleiche die Anzeige bei gleichmäßigem Geräusch mit einem Referenzmessgerät. Ist die App 5 dB zu niedrig, erhöhe den Offset um 5. Ohne Referenz ist die Anzeige nur eine Orientierung.'),
      Text('Offset: ${offset.round()} dB'),
      Slider(value: offset, min: 0, max: 130, divisions: 130, label: '${offset.round()} dB', onChanged: (v) => setState(() { offset = v; })),
      const Text('Beim Wechsel zwischen Gelb und Rot beginnt die 10-Sekunden-Frist neu. Pro ununterbrochener Phase ertönt ein Alarm. Grün setzt den Alarm zurück.'),
      const SizedBox(height: 24), FilledButton(onPressed: () => Navigator.pop(context, Preferences(yellow, red, offset, sound)), child: const Text('Speichern')),
      TextButton(onPressed: () => setState(() { yellow = 60; red = 80; offset = 90; sound = true; }), child: const Text('Standardwerte')),
    ]));
}
class FacePainter extends CustomPainter {
  final int zone; final Color color;
  FacePainter(this.zone, this.color);
  @override void paint(Canvas c, Size s) {
    final p = Paint()..color = color;
    c.drawCircle(s.center(Offset.zero), s.width * .46, p);
    p.color = const Color(0xff243d3a);
    for (final x in [.34, .66]) { c.drawOval(Rect.fromCenter(center: Offset(s.width*x, s.height*.4), width: 14, height: 22), p); }
    p..style = PaintingStyle.stroke..strokeWidth = 8..strokeCap = StrokeCap.round;
    final path = Path()..moveTo(s.width*.3, s.height*(zone == 0 ? .59 : .7));
    path.quadraticBezierTo(s.width*.5, s.height*(zone == 0 ? .88 : .48), s.width*.7, s.height*(zone == 0 ? .59 : .7));
    c.drawPath(path, p);
    if (zone == 2) {
      p..style = PaintingStyle.fill..color = const Color(0xff49a6e9);
      for (final x in [.31, .69]) {
        final tear = Path()..moveTo(s.width*x, s.height*.48)..quadraticBezierTo(s.width*(x-.09), s.height*.66, s.width*x, s.height*.69)..quadraticBezierTo(s.width*(x+.09), s.height*.66, s.width*x, s.height*.48);
        c.drawPath(tear, p);
      }
    }
  }
  @override bool shouldRepaint(FacePainter old) => old.zone != zone || old.color != color;
}
