# Raumfreund

Kindgerechte Android-Lautstärkeampel mit Flutter/Dart und einem kleinen nativen Kotlin-Mikrofonmodul. Quellcode unter GPL-3.0-only.

## Funktionen
- Start/Stopp, freundliches, trauriges und weinendes Gesicht; farbige Skala 0–130 dB.
- Gelb ab 60 dB, Rot ab 80 dB; beide Grenzen in den Einstellungen veränderbar.
- Nach zehn Sekunden durchgehend in einer gelben oder roten Phase einmaliger Alarmton und Vibration. Farbwechsel setzt die Frist zurück; Grün aktiviert den Alarm erneut. Keine Daueralarm-Schleife.
- Kalibrierungsoffset und abschaltbarer Ton; Einstellungen lokal dauerhaft gespeichert.
- About-Seite mit Autorenschaft, GPL-v3-Hinweis und Bibliothekenübersicht.
- Mikrofonfreigabe erst beim Start. Audio wird nur im RAM ausgewertet, weder gespeichert noch übertragen. Beim Verlassen der App wird die Messung gestoppt; währenddessen bleibt der Bildschirm an.

## Android bauen
Voraussetzungen: aktuelles Flutter Stable SDK (Dart >=3.4), Android SDK/JDK laut `flutter doctor`, Python 3 und Bash (unter Windows z.B. WSL).

```sh
./tool/setup.sh
```
Das Skript erzeugt das reguläre Android-Hostprojekt mit den zu deiner Flutter-Version passenden Gradle-Dateien, installiert den Kotlin-Code und ergänzt die Berechtigungen. Danach laufen Analyse, Tests und der Debug-APK-Build.

APK: `build/app/outputs/flutter-apk/app-debug.apk`.

Anschließend: `flutter run` für ein angeschlossenes Android-Gerät. Für Veröffentlichung eine eigene Release-Signatur konfigurieren; die Debug-APK ist für lokale Erprobung.

## Messung
Aus PCM-Samples wird pro ca. 100 ms der RMS-Pegel in dBFS berechnet. Anzeige = dBFS + Kalibrierungsoffset (initial 90), begrenzt auf 0–130. Der Offset ist keine universelle physikalische Kalibrierung. Mikrofon, automatische Verstärkung und Frequenzgang beeinflussen die Anzeige. Mit einem Referenzmessgerät bei gleichmäßigem Geräusch abgleichen. Die Skala ist ein Schätzwert, kein zertifizierter dB-SPL-Messwert. Der Alarmton kann selbst auf die Messung wirken, löst aber innerhalb derselben Phase keinen weiteren Alarm aus.

## Autorenschaft und Lizenzen
Erstellt mit OpenAI Codex im Auftrag des Projektinhabers. Ein persönlicher Autorenname wurde noch nicht angegeben; der About-Text kann in `lib/main.dart` angepasst werden.
App: GNU GPL Version 3 ausschließlich, siehe LICENSE. Flutter/Dart: BSD-3-Clause; Kotlin Standard Library: Apache-2.0; Android SDK APIs: Plattform-APIs. Keine zusätzlichen Pub-Pakete zur Laufzeit. Flutter zeigt die im Build eingebundenen Lizenztexte über den About-Lizenzdialog an. Für Verteilung zusätzlich die Lizenzhinweise des verwendeten Flutter-/Android-Builds beibehalten.

## Validierung in der Erstellungsumgebung
Flutter/Dart und Android SDK waren nicht verfügbar; deshalb konnte kein APK-Build, Flutter-Analyzer oder Flutter-Testlauf durchgeführt werden. Die Tests sind enthalten. Vor Einsatz auf einem echten Android-Gerät testen: Mikrofonfreigabe/Verweigerung, Start/Stopp, Hintergrundwechsel, Neustart mit gespeicherten Einstellungen, zehn Sekunden Gelb/Rot, Rückkehr zu Grün, Kalibrierung und Alarmlautstärke.
