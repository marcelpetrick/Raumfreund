import 'package:flutter_test/flutter_test.dart';
import 'package:raumfreund/meter.dart';
void main() {
  test('yellow triggers exactly at ten seconds and only once', () {
    final m = NoiseMonitor();
    for (int i = 0; i < 100; i++) {
      expect(m.sample(65, Duration(milliseconds: i * 100)), isFalse);
    }
    expect(m.sample(65, const Duration(seconds: 10)), isTrue);
    expect(m.sample(65, const Duration(milliseconds: 10100)), isFalse);
  });
  test('zone changes restart the timer, green rearms', () {
    final m = NoiseMonitor();
    for (int i = 0; i < 100; i++) { m.sample(65, Duration(milliseconds: i * 100)); }
    expect(m.sample(85, const Duration(seconds: 10)), isFalse);
    for (int i = 101; i < 200; i++) { expect(m.sample(85, Duration(milliseconds: i * 100)), isFalse); }
    expect(m.sample(85, const Duration(seconds: 20)), isTrue);
    m.sample(40, const Duration(milliseconds: 20100));
    expect(m.zone, Zone.green);
    expect(m.elapsed, Duration.zero);
    expect(m.sample(85, const Duration(milliseconds: 20200)), isFalse);
  });
  test('missing samples cannot count as continuous loudness', () {
    final m = NoiseMonitor();
    m.sample(80, Duration.zero);
    expect(m.sample(80, const Duration(seconds: 12)), isFalse);
    expect(m.elapsed, Duration.zero);
  });
  test('threshold equality and reset', () {
    final m = NoiseMonitor();
    m.sample(60, Duration.zero); expect(m.zone, Zone.yellow);
    m.sample(80, const Duration(milliseconds: 100)); expect(m.zone, Zone.red);
    m.reset(); expect(m.zone, Zone.green); expect(m.elapsed, Duration.zero);
  });
}
