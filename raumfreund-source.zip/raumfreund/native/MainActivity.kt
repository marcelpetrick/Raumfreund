package org.raumfreund.raumfreund

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import kotlin.math.log10
import kotlin.math.sqrt

class MainActivity : FlutterActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private var sink: EventChannel.EventSink? = null
    private var pending: MethodChannel.Result? = null
    @Volatile private var active = false
    private var worker: Thread? = null
    private var recorder: AudioRecord? = null
    private var tone: ToneGenerator? = null
    private val prefs by lazy { getSharedPreferences("raumfreund", MODE_PRIVATE) }

    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        EventChannel(engine.dartExecutor.binaryMessenger, "raumfreund/levels").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(args: Any?, events: EventChannel.EventSink) { sink = events }
            override fun onCancel(args: Any?) { stopMeter(); sink = null }
        })
        MethodChannel(engine.dartExecutor.binaryMessenger, "raumfreund/control").setMethodCallHandler { call, result ->
            when (call.method) {
                "settings" -> result.success(mapOf("yellow" to prefs.getFloat("yellow", 60f).toDouble(), "red" to prefs.getFloat("red", 80f).toDouble(), "offset" to prefs.getFloat("offset", 90f).toDouble(), "sound" to prefs.getBoolean("sound", true)))
                "saveSettings" -> {
                    val yellow = call.argument<Number>("yellow")?.toFloat()
                    val red = call.argument<Number>("red")?.toFloat()
                    val offset = call.argument<Number>("offset")?.toFloat()
                    if (yellow == null || red == null || offset == null || !yellow.isFinite() || !red.isFinite() || !offset.isFinite() || yellow < 0 || red > 130 || yellow >= red || offset !in 0f..130f) result.error("settings", "Ungültige Grenzen", null)
                    else {
                        val saved = prefs.edit().putFloat("yellow", yellow).putFloat("red", red).putFloat("offset", offset).putBoolean("sound", call.argument<Boolean>("sound") ?: true).commit()
                        if (saved) result.success(null) else result.error("storage", "Speichern fehlgeschlagen", null)
                    }
                }
                "start" -> {
                    if (pending != null) result.error("busy", "Berechtigungsanfrage läuft", null)
                    else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        pending = result
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 31)
                    } else startMeter(result)
                }
                "stop" -> {
                    pending?.error("cancelled", "Messung abgebrochen", null); pending = null
                    stopMeter(); result.success(null)
                }
                "alarm" -> {
                    try {
                        if (call.argument<Boolean>("sound") != false) {
                            tone?.release()
                            tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 75)
                            tone?.startTone(ToneGenerator.TONE_PROP_BEEP2, 500)
                        }
                        val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
                        if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
                        else { @Suppress("DEPRECATION") vibrator.vibrate(300) }
                        result.success(null)
                    } catch (e: Exception) { result.error("alarm", e.message, null) }
                }
                else -> result.notImplemented()
            }
        }
    }
    override fun onRequestPermissionsResult(code: Int, permissions: Array<out String>, grants: IntArray) {
        super.onRequestPermissionsResult(code, permissions, grants)
        if (code == 31) {
            val result = pending ?: return
            pending = null
            if (grants.firstOrNull() == PackageManager.PERMISSION_GRANTED) startMeter(result)
            else result.error("permission", "Mikrofonzugriff verweigert", null)
        }
    }
    private fun startMeter(result: MethodChannel.Result) {
        if (active) { result.success(null); return }
        try {
            val minimum = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            check(minimum > 0) { "Audioformat nicht unterstützt" }
            val audio = AudioRecord(MediaRecorder.AudioSource.MIC, 44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minimum, 8820) * 2)
            recorder = audio
            check(audio.state == AudioRecord.STATE_INITIALIZED) { "Mikrofon nicht verfügbar" }
            audio.startRecording()
            check(audio.recordingState == AudioRecord.RECORDSTATE_RECORDING)
            active = true
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            worker = Thread {
                val buffer = ShortArray(4410)
                try {
                    while (active) {
                        val count = audio.read(buffer, 0, buffer.size)
                        if (!active) break
                        check(count > 0) { "Audiomessung unterbrochen" }
                        var sum = 0.0
                        for (i in 0 until count) { val v = buffer[i].toDouble() / 32768; sum += v * v }
                        val level = 20 * log10(maxOf(sqrt(sum / count), 0.000001))
                        handler.post { if (active) sink?.success(level) }
                    }
                } catch (e: Exception) {
                    handler.post { if (active) { sink?.error("audio", e.message, null); stopMeter() } }
                }
            }.also { it.start() }
            result.success(null)
        } catch (e: Exception) { stopMeter(); result.error("audio", e.message, null) }
    }
    private fun stopMeter() {
        active = false
        try { recorder?.stop() } catch (_: Exception) {}
        worker?.join(500)
        worker = null
        recorder?.release(); recorder = null
        tone?.release(); tone = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
    override fun onPause() { stopMeter(); super.onPause() }
    override fun onDestroy() { stopMeter(); pending?.error("cancelled", "App beendet", null); pending = null; super.onDestroy() }
}
