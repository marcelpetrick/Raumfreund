#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v flutter >/dev/null || { echo 'Bitte Flutter SDK installieren und flutter zum PATH hinzufügen.'; exit 1; }
flutter create --platforms=android --org org.raumfreund --project-name raumfreund --no-pub .
mkdir -p android/app/src/main/kotlin/org/raumfreund/raumfreund
cp native/MainActivity.kt android/app/src/main/kotlin/org/raumfreund/raumfreund/MainActivity.kt
python3 - <<'PY'
from pathlib import Path
p = Path('android/app/src/main/AndroidManifest.xml')
s = p.read_text()
s = s.replace('<application', '<uses-permission android:name="android.permission.RECORD_AUDIO"/>\n    <uses-permission android:name="android.permission.VIBRATE"/>\n    <application', 1)
s = s.replace('android:label="raumfreund"', 'android:label="Raumfreund"')
p.write_text(s)
# Generated Flutter tests target the default counter app.
Path('test/widget_test.dart').unlink(missing_ok=True)
PY
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
